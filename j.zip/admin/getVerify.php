<?php 
require_once '../include.php';
verifyImage();